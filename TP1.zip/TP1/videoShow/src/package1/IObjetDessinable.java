package package1;

import java.awt.Graphics;

public interface IObjetDessinable {
	void dessiner(Graphics g);

}
