package package1;

public interface IObjetAnnimable extends IObjetDessinable{

	 void deplacer();
}
